public class Constants {
	public final static int GRID_X = 30;
	public final static int GRID_Y = 20;
	public final static int PIXELS_PER_SQUARE = 40; //needs to be changed eventually
	public static int TIME = 0;
	public static boolean READY_UPDATE = false;
}